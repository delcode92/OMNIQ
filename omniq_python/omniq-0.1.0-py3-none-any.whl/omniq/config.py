"""
Configuration module for OmniQ.
"""
import os
from typing import Optional


class Config:
    """Configuration class for OmniQ client."""
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize configuration.
        
        Args:
            api_key: OpenAI API key
            base_url: Custom base URL for the API gateway
        """
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY")
        if not self.api_key:
            raise ValueError("API key must be provided or set in OPENAI_API_KEY environment variable")
        
        self.base_url = base_url or os.environ.get("OMNIQ_BASE_URL", "https://api.openai.com/v1")
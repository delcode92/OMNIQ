"""
HTTP client module for OmniQ.
"""
import json
import requests
from typing import Dict, Any
from .exceptions import OmniQAPIError


class HttpClient:
    """HTTP client for making requests to the OpenAI API."""
    
    def __init__(self, config):
        """
        Initialize HTTP client with configuration.
        
        Args:
            config: Config object containing API settings
        """
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.config.api_key}",
            "Content-Type": "application/json"
        })
    
    def post(self, endpoint: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make a POST request to the API.
        
        Args:
            endpoint: API endpoint to call
            data: Data to send in the request body
            
        Returns:
            Dict containing the API response
            
        Raises:
            OmniQAPIError: If the request fails
        """
        url = f"{self.config.base_url}{endpoint}"
        
        try:
            response = self.session.post(url, json=data)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.RequestException as e:
            raise OmniQAPIError(f"API request failed: {str(e)}") from e
        except json.JSONDecodeError as e:
            raise OmniQAPIError(f"Failed to decode JSON response: {str(e)}") from e
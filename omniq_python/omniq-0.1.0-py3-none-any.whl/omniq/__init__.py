"""
OmniQ - A Python wrapper module for OpenAI that redirects to your gateway.
"""
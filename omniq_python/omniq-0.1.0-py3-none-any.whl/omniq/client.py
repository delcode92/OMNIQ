"""
Client module for OmniQ - A Python wrapper for OpenAI.
"""
from typing import Optional, Dict, Any
from .config import Config
from .http import HttpClient
from .exceptions import OmniQError


class OmniQClient:
    """Main client for interacting with the OpenAI API through OmniQ."""
    
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        """
        Initialize the OmniQ client.
        
        Args:
            api_key: OpenAI API key
            base_url: Custom base URL for the API gateway
        """
        self.config = Config(api_key=api_key, base_url=base_url)
        self.http_client = HttpClient(self.config)
    
    def completions_create(self, model: str, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Create a completion for the given prompt.
        
        Args:
            model: The model to use for completion
            prompt: The prompt to complete
            **kwargs: Additional arguments to pass to the API
            
        Returns:
            Dict containing the API response
        """
        payload = {
            "model": model,
            "prompt": prompt,
            **kwargs
        }
        return self.http_client.post("/completions", payload)
    
    def chat_completions_create(self, model: str, messages: list, **kwargs) -> Dict[str, Any]:
        """
        Create a chat completion.
        
        Args:
            model: The model to use for chat completion
            messages: List of messages for the conversation
            **kwargs: Additional arguments to pass to the API
            
        Returns:
            Dict containing the API response
        """
        payload = {
            "model": model,
            "messages": messages,
            **kwargs
        }
        return self.http_client.post("/chat/completions", payload)
"""
Utility functions for OmniQ.
"""


def sanitize_params(params: dict) -> dict:
    """
    Sanitize parameters by removing None values.
    
    Args:
        params: Dictionary of parameters
        
    Returns:
        Dictionary with None values removed
    """
    return {k: v for k, v in params.items() if v is not None}


def format_response(response: dict) -> dict:
    """
    Format API response for consistent output.
    
    Args:
        response: Raw API response
        
    Returns:
        Formatted response
    """
    # For now, just return the response as-is
    # Can be extended for custom formatting
    return response
"""
Custom exceptions for OmniQ.
"""


class OmniQError(Exception):
    """Base exception class for OmniQ errors."""
    pass


class OmniQAPIError(OmniQError):
    """Exception raised for API-related errors."""
    pass


class OmniQConfigError(OmniQError):
    """Exception raised for configuration-related errors."""
    pass